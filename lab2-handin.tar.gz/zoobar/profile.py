from flask import g
from debug import *

import rpclib
import traceback

def run_profile(user):
    return 'This code will appear in lab 3'
