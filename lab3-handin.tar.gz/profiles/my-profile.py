#!python

# add a feature to let user to see the visitor's log
# SOLUTION:
# add a new service named visitor_svc and create a new database table with specific permission
global api
user = api.call('get_self')

print 'Hello, <i>', api.call('get_visitor'),'<i>'
print 'Here are the visitor log\n'
print api.call('get_visitorlog')

# Your code goes here.
